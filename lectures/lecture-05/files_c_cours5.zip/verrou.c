#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#define LENTAB 15

int globale;
pthread_mutex_t verrou_glob = PTHREAD_MUTEX_INITIALIZER;

void *serve(void *arg) {
  pthread_mutex_lock(&verrou_glob);
  int tmp = globale;
  globale += 1;
  printf("variable globale : %d + 1  = %d \n", tmp, globale);
  pthread_mutex_unlock(&verrou_glob);
 
  return NULL;
}

int main(int argc, char *argv[]){
  int compt = 0;
  pthread_t tpthread[LENTAB];

  while(compt < LENTAB){
    pthread_t thread;
      
    if (pthread_create(&tpthread[compt], NULL, serve, NULL) == -1) {
      perror("pthread_create");
      continue;
    }  
    compt++;
  }

  for(int i=0; i<LENTAB; i++)
    pthread_join(tpthread[i], NULL);

  return 0;
}
